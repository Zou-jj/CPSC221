#include "block.h"
#include <cmath>
#include <iostream>

int Block::height() const {
  /* your code here */
  return data[0].size();
}

int Block::width() const {
  /* your code here */
  return data.size();
}

void Block::render(PNG &im, int x) const {
  /* your code here */
  for(int i = 0; i < width(); i++) {
    for(unsigned int h = 0; h < im.height(); h++) {
      *(im.getPixel(x+i,h)) = data[i][h];
    }
  }
  return;
}

void Block::build(PNG &im, int x, int width) {
  /* your code here */
  data = vector<vector<HSLAPixel>>(width);
  for(int i = 0; i < width; i++) {
    data[i] = vector<HSLAPixel>(im.height());
    for(unsigned int h = 0; h < im.height(); h++) {
      data[i][h] = *(im.getPixel(x+i,h));
    }
  }
  return;
}
