#include "stats.h"


#include "stats.h"

stats::stats(PNG & im){

/* Your code here!! */

}


long stats::getSum(char channel, pair<int,int> ul, int w, int h){
/* Your code here!! */
}

long stats::getSumSq(char channel, pair<int,int> ul, int w, int h){
/* Your code here!! */
}

// given a rectangle, compute its sum of squared deviations from mean, over all color channels.
// see written specification for a description of this function.
double stats::getVar(pair<int,int> ul, int w, int h){
/* Your code here!! */

}
		
RGBAPixel stats::getAvg(pair<int,int> ul, int w, int h){
/* Your code here!! */

}
