#include "chain.h"
#include <cmath>
#include <iostream>


// PA1 functions

/**
 * Destroys the current Chain. This function should ensure that
 * memory does not leak on destruction of a chain.
 */
Chain::~Chain() {
  clear();
}

/**
 * Inserts a new node after the node pointed to by p in the
 * chain (so p->next is the new node) and returns a pointer to
 * the newly created node.
 * If p is NULL, inserts a new head node to the chain.
 * This function **SHOULD** create a new Node and increase length_.
 *
 * @param p = The new node should be pointed to by p->next.
 *            If p is NULL, the new node becomes the head of the chain.
 * @param ndata = The data to be inserted.
 */
Chain::Node * Chain::insertAfter(Node * p, const Block &ndata) {
  /* your code here */
  if(p == NULL) {
    head_ = new Node(ndata);
    length_ = 1;
    return head_;
  } else if(p->next != NULL){
    Node* newNode = new Node(ndata);
    newNode->prev = p;
    p->next->prev = newNode;
    newNode->next = p->next;
    p->next = newNode;
  } else {
    Node* newNode = new Node(ndata);
    newNode->prev = p;
    p->next = newNode;
  }
  length_++;
  return p->next;
}

/**
 * Swaps the position in the chain of the two nodes pointed to
 * by p and q.
 * If p or q is NULL or p==q, do nothing.
 * Change the chain's head pointer if necessary.
 */
void Chain::swap(Node *p, Node *q) {   
  /* your code here */
  if(p != q && p != NULL && q !=NULL) {
    if(p->next == q) {
      if(p->prev == NULL) 
        head_ = q;
      else
        p->prev->next = q;
      if(q->next != NULL) 
        q->next->prev = p;
      q->prev = p->prev;
      p->next = q->next;
      p->prev = q;
      q->next = p;
    } else if(q->next == p) {
      if(q->prev == NULL) 
        head_ = p;
      else
        q->prev->next = p;
      if(p->next != NULL) 
        p->next->prev = q;
      p->prev = q->prev;
      q->next = p->next;
      q->prev = p;
      p->next = q;
    } else {
      if(p->prev != NULL)
        p->prev->next = q;
      else
        head_ = q;
      if(p->next != NULL)
        p->next->prev = q;
      if(q->prev != NULL)
        q->prev->next = p;
      else
        head_ = p;
      if(q->next != NULL)
        q->next->prev = p;
      Node* pnext = p->next;
      Node* qprev = q->prev;
      q->prev = p->prev;
      p->next = q->next;
      q->next = pnext;
      p->prev = qprev;
    }
  }
  return;
}

/**
 * Destroys all dynamically allocated memory associated with the
 * current Chain class.
 */
void Chain::clear() {
  Node* curr = head_;
  Node* next;
  while(curr != NULL) {
    next = curr->next;
    delete curr;
    curr = next;
  }
  curr = NULL;
  next = NULL;
  head_ = NULL;
}


/**
 * Makes the current object into a copy of the parameter:
 * All member variables should have the same value as
 * those of other, but the memory should be completely
 * independent. This function is used in both the copy
 * constructor and the assignment operator for Chains.
 */
void Chain::copy(Chain const &other) {
  /* your code here */
  clear();
  length_ = other.length_;
  if(other.head_ == NULL) {
    head_ = NULL;
    return;
  } else {
    head_ = new Node(other.head_->data);
    Node* curr = head_;
    Node* currOther = other.head_;
    while(currOther->next != NULL) {
      curr->next = new Node(currOther->next->data);
      curr->next->prev = curr;
      curr = curr->next;
      currOther = currOther->next;
    }
  }
  
  
}

/* Modifies the current chain: 
 * 1) Find the node with the first (leftmost) block in the unscrambled
 *    image and move it to the head of the chain.
 *	This block is the one whose closest match (to the left) is the
 *	largest.  That is, the distance (using distanceTo) to this block 
 *	is big for all other blocks.
 *	For each block B, find the distanceTo B from every other block
 *	and take the minimum of these distances as B's "value".
 *	Choose the block B with the maximum value over all blocks and
 *	swap its node to the head of the chain.
 *
 * 2) Starting with the (just found) first block B, find the node with
 *    the block that is the closest match to follow B (to the right)
 *    among the remaining blocks, move (swap) it to follow B's node,
 *    then repeat to unscramble the chain/image.
 */
void Chain::unscramble() {
  /* your code here */
  if(head_ == NULL)
    return;
  distanceMax();
  Node* curr = head_;
  while(curr != NULL) {
    Node* tmp = curr->next;
    Node* closest;
    double distance = 1000000;
    while(tmp != NULL) {
      if((curr->data).distanceTo(tmp->data) < distance) {
        closest = tmp;
        distance = (curr->data).distanceTo(tmp->data);
      }
      tmp = tmp->next;
    }
    swap(curr->next, closest);
    curr = curr->next;
  }

}

/**
 * This is a helper function for unscramble.
 * find the left block of image (task 1 in unscramble)
 * Make that block the head of chain.
 */
void Chain::distanceMax() {
  return;
}
